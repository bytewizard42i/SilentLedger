# SilentLedger → Alice (Review Package)

Hi Alice,

You’re invited to review the latest SilentLedger repo (Compact 0.15). Below is a concise handoff with what changed, how to run, and open items.

---

## What Changed
- Contracts updated to Compact 0.15:
  - `contracts/AssetVerification.compact`: `checkVerification(owner, assetId, proofHash, currentTime)` now enforces expiry; safe map access for `usedProofs`.
  - `contracts/ObfuscatedOrderbook.compact`: `checkVerification` imported top-level; passes `currentTime` in `placeOrder`.
  - `contracts/SilentOrderbook.compact`: No changes required.
- Docs refreshed in `README.md`:
  - Compatibility (0.15), Dev Quick Start, Example Usage, Security notes, Arch diagram instructions.
- Frontend/Mock server verified for signature alignment: `public/midnight-wallet.js`, `src/api/mock-wallet-server.js`.

---

## How To Run (Dev)
1. Install deps:
   - `yarn install`
2. Start services:
   - Mock Wallet: `node src/api/mock-wallet-server.js` (PORT 3001 default)
   - App server: `node server.js` (serves `public/`)
3. Open UI:
   - http://localhost:8080

Key endpoints:
- POST `http://localhost:3001/api/wallet/:wallet/verify-ownership`
- POST `http://localhost:3001/api/orders`

---

## Files To Review First
- Contracts: `contracts/*.compact`
- Mock server: `src/api/mock-wallet-server.js`
- Wallet integration: `public/midnight-wallet.js`
- App logic & simulation: `public/app.js`
- Docs: `README.md`, `AI-chat.md`

---

## Open Items / Questions for Alice
1. Would you like signature-based API auth added to the mock server now (HMAC or ECDSA)?
2. Any preference on commitment scheme layout for `SilentOrderbook` (salt ordering / domain separation)?
3. Should we include an explicit `disclose(...)` example in a safe context to educate readers, or keep it minimal?
4. Architecture diagram draft preferences (Mermaid vs SVG)?

---

## Notes
- myAlice/SoulSketch: Not found in this repo. If you share paths or repos, I’ll upgrade them independently (keeping protocols separate).
- See `AI-chat.md` for a log of the recent upgrade session.

Thanks!
